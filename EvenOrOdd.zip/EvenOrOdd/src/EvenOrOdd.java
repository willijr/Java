// Jeffrey Williams
// Project 3
// COP 3330 Object Oriented Programming

/* 6.17 (Even or Odd) Write a method isEven that uses the remainder operator (%) to determine
whether an integer is even. The method should take an integer argument and return true if the 
integer is even and false otherwise. Incorporate this method into an application that inputs 
a sequence of integers (one at a time) and determines whether each is even or odd.*/

import java.util.Scanner;

public class EvenOrOdd 
{
	// determine if an integer entered is even or odd
	public static void main(String[] args) 
	{
		boolean result;
		int number;
		
		System.out.print("Please enter an integer to determine if it is even (enter 0 to end): ");
		// create Scanner for input from command window
	    Scanner input = new Scanner(System.in);
	    
		number = input.nextInt(); // user input for integer to test

		while (number != 0) // while number does not equal 0, 0 will end the program
		{
		
			result = isEven(number); //calls isEven method with number as the variable
			
			if (result == true) // if number returned true
			{
				System.out.printf("The number %d is even!\nPlease enter another integer to "
						+ "determine if it is even (enter 0 to end): ", number);
				number = input.nextInt(); // user input for next integer to test
			} // end if true
			
			else if (result == false) // if number returned false
			{
				System.out.printf("The number %d is odd!\nPleae enter another integer to "
						+ "determine if it is even (enter 0 to end): ", number);
				number = input.nextInt(); // user input for next integer to test
			} // end if false
		} // end while loop
			System.out.println("Thank you, the program will now end");
	} // end main
	
	// method to return true if integer entered is even, false if not
	public static boolean isEven(int x)
	{
	   if (x % 2 == 0) // even
		   return true;
	   else // false
		   return false;
	}
} // end class EvenOrOdd