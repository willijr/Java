// Jeffrey Williams
// COP 3330 Object Oriented Programming
/* Use inheritance to create an exception superclass (called ExceptionA) and exception subclasses 
 * ExceptionB and ExceptionC, where ExceptionB inherits from ExceptionA and ExceptionC inherits 
 * from ExceptionB. Write a program to demonstrates that a catch block for type ExceptionA catches 
 * exceptions of types ExceptionB and ExeptionC. So the program should show exceptions of types 
 * ExceptionB and ExeptionC being caught by a catch block that only catches ExceptionA. */

public class ExceptionA 
{

	// call ExceptionB; throw exceptions back to main
	public static void exceptionA() 
	throws Exception
	{
		try 
		{ 
			ExceptionB.exceptionB(); 
		}
		catch (Exception exception) // exception thrown from ExceptionB
		{
			throw new Exception("Exception thrown in ExceptionA", exception);
		}
	} // end method exceptionA
} // end class ExceptionA