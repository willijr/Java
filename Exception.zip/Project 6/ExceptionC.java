// Jeffrey Williams
// COP 3330 Object Oriented Programming
/* Use inheritance to create an exception superclass (called ExceptionA) and exception subclasses 
 * ExceptionB and ExceptionC, where ExceptionB inherits from ExceptionA and ExceptionC inherits 
 * from ExceptionB. Write a program to demonstrates that a catch block for type ExceptionA catches 
 * exceptions of types ExceptionB and ExeptionC. So the program should show exceptions of types 
 * ExceptionB and ExeptionC being caught by a catch block that only catches ExceptionA. */

public class ExceptionC {

	// throw Exception back to ExceptionB
	public static void exceptionC() throws Exception
	{
		throw new Exception("Exception thrown in ExceptionC");
	} // end method exceptionC
} // End Class ExceptionC