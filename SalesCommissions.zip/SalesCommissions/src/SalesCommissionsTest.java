// Jeffrey Williams
// COP 3330 Object Oriented Programming
// Project 4

/* 7.10 (Sales Commissions) Use a one-dimensional array to solve the following problem: A company
pays its salespeople on a commission basis. The salespeople receive $200 per week plus 9% of
their gross sales for that week. For example, a salesperson who grosses $5,000 in sales in a week receives
$200 plus 9% of $5,000, or a total of $650. Write an application (using an array of counters)
that determines how many of the salespeople earned salaries in each of the following ranges (assume
that each salesperson’s salary is truncated to an integer amount):
a) $200–299
b) $300–399
c) $400–499
d) $500–599
e) $600–699
f) $700–799
g) $800–899
h) $900–999
i) $1,000 and over
Summarize the results in tabular format. */

import java.util.Scanner;

public class SalesCommissionsTest
{ 
   // main method begins program execution
   public static void main(String[] args)
   {	   
	  Scanner input = new Scanner(System.in);
	    
	  System.out.printf("Please enter the total employees to calculate commissions: ");
	  int employees = input.nextInt(); // user input for number of sales employees
	  double[] totalPayArray = new double[employees]; // setting the length of the one dimensional array

      for (int i = 0; i < employees; i++) // gathering sales to calculate commissions
	  {
		 System.out.printf("Please enter the total sales for employee %s to calculate commissions: $", i + 1);
	     double number = input.nextDouble(); // user input for sales for each employee
	     double commission = (number * .09); // calculates the commission based on the 9% rate
		 totalPayArray[i] = 200.00 + commission; // one-dimensional array of employee totalPay which equals base pay $200 plus the 9% commission
	  } 
      input.close(); // closing scanner input
      
      SalesCommissions mySalesCommissions = new SalesCommissions("Tv Sales, Inc.", totalPayArray);
      System.out.printf("%n%nThis is the pay table for employees at: %s%n%n", mySalesCommissions.getCompanyName());
      mySalesCommissions.processPay();
   } 
} // end class SalesCommissionsTest
