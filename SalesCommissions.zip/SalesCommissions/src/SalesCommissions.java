// Jeffrey Williams
// COP 3330 Object Oriented Programming
// Project 4

/* 7.10 (Sales Commissions) Use a one-dimensional array to solve the following problem: A company
pays its salespeople on a commission basis. The salespeople receive $200 per week plus 9% of
their gross sales for that week. For example, a salesperson who grosses $5,000 in sales in a week receives
$200 plus 9% of $5,000, or a total of $650. Write an application (using an array of counters)
that determines how many of the salespeople earned salaries in each of the following ranges (assume
that each salesperson’s salary is truncated to an integer amount):
a) $200–299
b) $300–399
c) $400–499
d) $500–599
e) $600–699
f) $700–799
g) $800–899
h) $900–999
i) $1,000 and over
Summarize the results in tabular format. */

// SalesCommissions class using an array to store employee total pay.
public class SalesCommissions
{
   private String companyName; // name of company this SalesCommissions represents
   private double[] totalPay; // array of employee totalPay
   
   // constructor
   public SalesCommissions(String name, double[] totalPay)
   {
      this.companyName = name;
      this.totalPay = totalPay; 
   } 

   // method to set the company name
   public void setCompanyName(String companyName)
   {
      this.companyName = companyName; 
   } 

   // method to retrieve the company name
   public String getCompanyName()
   {
      return companyName;
   } 

   // perform various operations on the data
   public void processPay()
   {
      // output totalPay array
      outputPay();

      // call method getAverage to calculate the average pay      
      System.out.printf("%nEmployee average pay is $%.2f%n", getAverage()); 

      // call methods getMinimum and getMaximum
      System.out.printf("Lowest pay is $%.2f%nHighest pay is $%.2f%n%n",
         getMinimum(), getMaximum());

      // call outputBarChart to print pay distribution chart
      outputBarChart();
   } 

   // find minimum pay
   public double getMinimum()
   { 
      double lowPay = totalPay[0]; // assume totalPay[0] is smallest

      // loop through totalPay array
      for (double pay : totalPay) 
      {
         // if pay is lower than lowPay, assign it to lowPay
         if (pay < lowPay)
            lowPay = pay; // new lowest pay
      } 

      return lowPay; 
   } 

   // find maximum pay
   public double getMaximum()
   { 
      double highPay = totalPay[0]; // assume totalPay[0] is largest

      // loop through totalPay array
      for (double pay : totalPay) 
      {
         // if pay is greater than highPay, assign it to highPay
         if (pay > highPay)
            highPay = pay; // new highest pay
      }

      return highPay; 
   } 

   // determine average pay for employee
   public double getAverage()
   {      
      double total = 0; 
 
      // sum totalPay for all employees
      for (double pay : totalPay)
         total += pay;

      // return average of totalPay
      return total / totalPay.length;
   } 

   // output bar chart displaying pay distribution
   public void outputBarChart()
   {
      System.out.println("Pay distribution:");

      // stores frequency of totalPay in each range of $100 totalPay
      int[] frequency = new int[11];
      
      // for each pay, increment the appropriate frequency 
      for (double pay : totalPay)
         if (pay > 1000) // to get the asterisks for higher than $1000, there are no ranges for $1100-1199, etc.
        	 ++frequency[10]; // adds one more to the $1,000 up category
         else
        	 ++frequency[(int) (pay / 100)]; 

      // for each pay frequency, print bar in chart
      for (int count = 2; count < frequency.length; count++) // starting count at 2 because 0-99 and 100-199 is skipped
      {
         // output bar label ("$200-$299: ", ..., "$900-$999: ", "$1,000 up: ")
         if (count == 10)
            System.out.printf("$1,000 up: "); 
         else
            System.out.printf("$%02d-$%02d: ", 
               count * 100 , count * 100 + 99); 
         
         // print bar of asterisks
         for (int asterisks = 0; asterisks < frequency[count]; asterisks++)
            System.out.print("*");

         System.out.println(); 
      } 
   } 

   // output the contents of the totalPay array
   public void outputPay()
   {    
      System.out.printf("The total pay by employee is:%n%n");
      
      // output each employee's pay
      for (int i = 0; i < totalPay.length; i++) 
         System.out.printf("Employee %2d: $%.2f%n", 
            i + 1, totalPay[i]);
   } 
} // end class SalesCommissions