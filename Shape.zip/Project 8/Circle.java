// Jeffrey Williams

public class Circle extends TwoDimensional 
{
	// constructor
	public Circle(double number1)
	{
		super(number1); 
	} 
   
	public String getDimension()
	{
		return dimension = "two dimensional";
	}

	public String getArea()
	{
		number3 = Math.PI * Math.pow(number1, 2);
		number3 = (double) Math.round(number3 * 100) / 100;
		area = String.valueOf(number3);
		return area;
	}   
} // end class Circle
