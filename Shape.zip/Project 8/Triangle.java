// Jeffrey Williams

public class Triangle extends TwoDimensional 
{
	// constructor
	public Triangle(double height, double base)
	{
		super(number1);
		number2 = base;
	} 
   
	public String getDimension()
	{
		return dimension = "two dimensional";
	}
   
	public String getArea()
	{
		number3 = (number1 * number2) / 2;
		number3 = (double) Math.round(number3 * 100) / 100;
		area = String.valueOf(number3);
		return area;
	}	
} // end class Triangle