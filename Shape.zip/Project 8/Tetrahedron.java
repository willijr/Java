// Jeffrey Williams

public class Tetrahedron extends ThreeDimensional 
{
	// constructor
	public Tetrahedron(double side)
	{
		super(number1);  
	}
   
	public String getDimension()
	{
		return dimension = "three dimensional";
	}
   
	public void setArea()
	{
		number3 = (number1 * number1) / 2;
		number3 = (double) Math.round(number3 * 100) / 100;
		area = String.valueOf(number3);
		number4 = ((Math.pow(number1, 3)) / (6 * Math.sqrt(2)));
		number4 = (double) Math.round(number4 * 100) / 100;
		volume = String.valueOf(number4);
	}
   
	public String getArea()
	{
		setArea();
		return area + " and a volume of " + volume;
	}   
} // end class Tetrahedron