// Jeffrey Williams

public class Square extends TwoDimensional 
{
	// constructor
	public Square(double side)
	{
		super(number1); 
	} 
   
	public String getDimension()
	{
		return dimension = "two dimensional";
	}
   
	public String getArea()
	{
		number3 = number1 * number1;
		number3 = (double) Math.round(number3 * 100) / 100;
		area = String.valueOf(number3);
		return area;
	}
} // end class Square