// Jeffrey Williams

public class ShapeHierarchyTest 
{
	public static void main(String[] args) 
	{
		// create subclass objects
		Circle circle = new Circle(2);
		Square square = new Square(2);
		Triangle triangle = new Triangle(2, 4);
		Sphere sphere = new Sphere(2);
		Cube cube = new Cube(2);
		Tetrahedron tetrahedron = new Tetrahedron(2);
      
		// create four-element TwoDimensional array
		TwoDimensional[] shapes = new TwoDimensional[6]; 

		// initialize array with TwoDimensionals
		shapes[0] = circle;
		shapes[1] = square;
		shapes[2] = triangle; 
		shapes[3] = sphere;
		shapes[4] = cube;
		shapes[5] = tetrahedron;

		// get type name of each object in shapes array
		for (int j = 0; j < shapes.length; j++)
		{
			System.out.printf("\nShape %d is a %s and is %s. It has an area of %s", j + 1, 
    			  shapes[j].getClass().getName(), shapes[j].getDimension(), shapes[j].getArea());
		}
	} // end main
} // end class ShapeHierarchyTest