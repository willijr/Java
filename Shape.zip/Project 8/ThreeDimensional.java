// Jeffrey Williams
// COP 3330 Object Oriented Programming
/* Implement the Shape hierarchy shown in Fig. 9.3 of the textbook. Each ThreeDimensionalShape should contain 
 * method getArea to calculate the area of the two-dimensional shape. Each ThreeDimensionalShape should have 
 * methods getArea and getVolume to calculate the surface area and volume, respectively, of the three-dimen-
 * sional shape. Create a program that uses an array of Shape references to objects of each concrete class in 
 * the hierarchy. The program should print a text description of the object to which each array element refers. 
 * Also, in the loop that processes all the shapes in the array, determine whether each shape is a 
 * ThreeDimensionalShape or a ThreeDimensionalShape. If a shape is a ThreeDimensionalShape, display its area. If a 
 * shape is a ThreeDimensionalShape, display its area and volume. */

public abstract class ThreeDimensional extends TwoDimensional
{
	public static double number4;
	public String volume;
	public static String area;

	public ThreeDimensional(double number1) 
	{
		super(number1);
	}

	public double getNumber1()
	{
		return number1;
	} 

	public double getNumber2()
	{
		return number2;
	} 

	public double getNumber3()
	{
		return number3;
	} 
   
	public double getNumber4()
	{
		return number4;
	} 

	public String getDimension()
	{
		return dimension;
	}
  
	public String getArea()
	{
		return area;
	}
} // end abstract class ThreeDimensional