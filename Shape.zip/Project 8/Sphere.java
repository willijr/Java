// Jeffrey Williams

public class Sphere extends ThreeDimensional 
{
	// constructor
	public Sphere(double radius)
	{
		super(number1);  
	}
   
	public String getDimension()
	{
		return dimension = "three dimensional";
	}
   
	public void setArea()
	{
		number3 = Math.PI * Math.pow(number1, 2);
		number3 = (double) Math.round(number3 * 100) / 100;
		area = String.valueOf(number3);
		number4 = (4/3) * Math.PI * Math.pow(number1, 3);
		number4 = (double) Math.round(number4 * 100) / 100;
		volume = String.valueOf(number4);
	}
   
	public String getArea()
	{
		setArea();
		return area + " and a volume of " + volume;
	}   
} // end class Sphere